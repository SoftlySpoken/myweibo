select ?Y1 ?Y2 ?Y3 where
{
?X <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#FullProfessor>.
?X <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#worksFor> <http://www.Department0.University0.edu>.
?X <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#name> ?Y1.
?X <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#emailAddress> ?Y2.
?X <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#telephone> ?Y3.
}
