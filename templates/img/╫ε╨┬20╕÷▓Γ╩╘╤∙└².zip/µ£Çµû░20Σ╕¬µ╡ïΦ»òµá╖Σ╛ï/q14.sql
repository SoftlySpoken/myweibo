select ?X ?Y where
{
?X <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#Student>.
?Y <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#Course>.
?X <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#takesCourse> ?Y.
<http://www.Department0.University0.edu/AssociateProfessor0> <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#teacherOf> ?Y.
}
