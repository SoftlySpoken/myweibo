select ?X ?Y ?Z where
{
?X <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#UndergraduateStudent>.
?Z <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#Course>.
?X <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#advisor> ?Y.
?Y <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#teacherOf> ?Z.
?X <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#takesCourse> ?Z.
}